package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Scanner;

public class PR {
	private static String me = "Vonrex";
	private String title;
	private String requested_by;
	private String description = "";
	private int percent_completion;
	private String status;
	private String update;
	private LinkedList<String> update_list = new LinkedList<String>();
	protected static LinkedList<PR> pr_list = new LinkedList<PR>();
	
	private static String folder_path = "PRL Data";
	
	public PR(String title,String requested_by, String description){
		this.setTitle(title);
		this.setRequested_by(requested_by);
		this.setDescription(description);
		this.setPercent_completion(0);
		this.setStatus("Still New!");
		this.update = "...";
		update_list.add(update);
		
		pr_list.add(this);
		System.out.printf("%nAdded a new PR titled: %s%n", this.getTitle());
		this.record();
		System.out.printf("%nRecorded a new PR titled: %s%n", this.getTitle());
	}
	
	
	
	public PR(){
		
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRequested_by() {
		return requested_by;
	}

	public void setRequested_by(String requested_by) {
		this.requested_by = requested_by;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPercent_completion() {
		return percent_completion;
	}

	public void setPercent_completion(int percent_completion) {
		this.percent_completion = percent_completion;
		record();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public void addAnUpdate(String update){
		update_list.add(update);
		record();
	}
	
	public LinkedList<String> getUpdates(){
		return update_list;
	}
	
	public void record(){
		try{
			if(new File(folder_path).exists()){
				if(new File(folder_path,this.title).exists()){
					this.addNewDataFile();
				}else{
					this.updateDataFile();
				}
			}else{
				File prl_data_folder = new File(folder_path);
				prl_data_folder.mkdir();
				
				buildDataFiles();
				
			}
		}catch(Exception e){
			System.out.println(e);
		}
	}


	private static void buildDataFiles() {
		try{
			if(new File(folder_path).exists()){
				for(PR pr : pr_list){
					pr.addNewDataFile();
					
				}
			}
		}catch(Exception e){
			System.out.println(e);
		}
		
	}

	private void updateDataFile() {
		addNewDataFile();
		
	}

	private void addNewDataFile() {
		try{
			PrintWriter prp = new PrintWriter(new FileOutputStream(folder_path+"/"+this.title+".txt"));
			prp.printf("Title: %s%n", this.title);
			prp.printf("Requestd by: %s%n", this.requested_by);
			prp.printf("Status: %s%n", this.status);
			prp.printf("Description: {%n%s%n}%n", this.description);
			prp.printf("Completed: %d%n", this.percent_completion);
			prp.printf("Updates: {%n");
			int i = 1;
			for(String update : update_list){
				prp.printf("%d.\t%s%n", i,update);
				i++;
			}
			prp.printf("}%n");
			
			prp.close();
		}catch(IOException e){
			System.out.println(e);
			
		}
		
	}
	
	public static void refreshPRList(){
		if(new File(folder_path).exists()){
			File[] all = new File(folder_path).listFiles();
			if(all.length > 0)
				for(File file : all){
					PR pr = new PR();
					pr.readDataFile(file);
					pr_list.add(pr);
					System.out.printf("%nAdded a new PR titled: %s%n", pr.getTitle());
				}
		}
	}
	
	
	private void readDataFile(File f){
		if(f.getPath().contains(".txt")){
			try{
				Scanner prs = new Scanner(new FileInputStream(f.getPath()));
				while(prs.hasNextLine()){
					String line = prs.nextLine();
					if(line.contains("Title:")){
						this.title = line.substring(line.indexOf(":")+1).trim();
					}
					if(line.contains("Requestd by:")){
						this.requested_by = line.substring(line.indexOf(":")+1).trim();
					}
					if(line.contains("Status:")){
						this.status = line.substring(line.indexOf(":")+1).trim();
					}
					if(line.contains("Description:")){
						while(!line.contains("}")){
							line = prs.nextLine();
							if(!line.contains("}")){
								this.description += line + "%n";
							}
						}
					}
					if(line.contains("Completed:")){
						this.percent_completion = Integer.parseInt(line.substring(line.indexOf(":")+1).trim());
					}
					if(line.contains("Updates:")){
						while(!line.contains("}")){
							line = prs.nextLine();
							if(!line.contains("}")){
								this.update = line.substring(2);
								this.update_list.add(update);
							}
						}
					}
				}
				prs.close();
			}catch(IOException e){
				System.out.println(e);
			}
		}
	}
	
	public String getLUpdate(){
		return this.update;
	}
	
	public void setLUpdate(String update){
		this.update = update;
		update_list.add(update);
	}
	
	public String toString(){
		return String.format("%s %n%s %n%s %n%s %n%s %n%d", this.title,this.status,this.requested_by,this.status,this.update,this.percent_completion);
	}
	
	
	

}
