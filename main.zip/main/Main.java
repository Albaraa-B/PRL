package main;

public class Main extends GUI{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//new GUI();
		
		new GUI();
		
		//PR.refreshPRList();
		/*PR test1 = new PR("Test1","Me","Testing Stuff");
		PR test2 = new PR("Test2","Me","Testing Stuff");
		PR test3 = new PR("Test3","Me","Testing Stuff");
		System.out.println(PR.pr_list.size());
		for(PR pr : PR.pr_list){
			System.out.printf("%s%n",pr.toString());
		}*/
		
	}

}
