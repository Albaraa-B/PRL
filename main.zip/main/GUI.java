package main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.border.LineBorder;

public class GUI extends JFrame implements ActionListener,MouseListener{
	protected static double version = 0.1;
	protected static JTabbedPane tb = new JTabbedPane();
	protected static JPanel queue_panel = new JPanel();
	protected static JPanel completed_panel = new JPanel();
	protected static JPanel bottom_panel = new JPanel();
	protected static LinkedList<JPanel> queue_list = new LinkedList<JPanel>();
	protected static LinkedList<JPanel> completed_list = new LinkedList<JPanel>();
	
	protected static JScrollPane queue_scroll = new JScrollPane(queue_panel);
	
	protected static JMenuBar mb = new JMenuBar();
	protected static JMenuItem refresh = new JMenuItem("Refresh List");
	protected static JMenuItem about = new JMenuItem("About");
	
	protected static JButton add_button = new JButton("Add a Request");
	
	protected static Component target;
	JPanel target_selected = null;
	private static PR targetPR;
	
	protected static JPanel side_panel = new JPanel();
	protected static JScrollPane side_scroll = new JScrollPane(side_panel);
	protected static JLabel side_title = new JLabel();
	protected static JLabel side_rby = new JLabel();
	protected static JLabel side_status = new JLabel();
	protected static JLabel side_desc = new JLabel();
	protected static JPanel side_updates = new JPanel();
	protected static JLabel side_percent = new JLabel();
	
	protected static JButton progress_button = new JButton("Set Progress");
	protected static JButton update_button = new JButton("Add an Update");
	
	
	
	
	public GUI(){
		super("PRL v"+version);
		PR.refreshPRList();
		getPRs();
		mb.add(refresh);
		mb.add(about);
		about.addActionListener(menu_lis);
		refresh.addActionListener(menu_lis);
		setJMenuBar(mb);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		tb.addTab("Queue", queue_scroll);
		queue_panel.addMouseListener(mouse_lis);
		queue_panel.setLayout(new GridLayout(0,1));
		completed_panel.setLayout(new GridLayout(0,1));
		tb.addTab("Completed",completed_panel);
		bottom_panel.add(add_button);
		add_button.addActionListener(button_lis);
		add(tb);
		add(bottom_panel,BorderLayout.SOUTH);
		side_panel.setSize(400,500);
		side_panel.setBackground(Color.WHITE);
		add(side_panel,BorderLayout.EAST);
		bottom_panel.add(progress_button,BorderLayout.SOUTH);
		progress_button.setVisible(false);
		progress_button.addActionListener(button_lis);
		bottom_panel.add(update_button);
		update_button.addActionListener(button_lis);
		update_button.setVisible(false);
		pack();
		setVisible(true);
	}
	
	MouseListener mouse_lis = new MouseListener(){

		@Override
		public void mouseClicked(MouseEvent e) {
			int x = e.getX();
			int y = e.getY();
			target = queue_panel.getComponentAt(x, y);
			if(target instanceof JPanel){
				((JPanel) target).setBorder(new LineBorder(Color.BLUE,2));
				if(target != target_selected && target_selected != null){
					target_selected.setBorder(new LineBorder(Color.BLACK,1));					
				}else if(target_selected != null){
					target_selected.setBorder(new LineBorder(Color.BLACK,1));
					target = null;
				}
				target_selected = (JPanel) target;
				
				if(target != null){
					JPanel pn = (JPanel) target;
					String s =  ((JLabel) pn.getComponent(0)).getText();
					s = s.substring(s.lastIndexOf(":") +1).trim();
					System.out.println(s);
					for(PR pr : PR.pr_list)
						if(pr.getTitle().contains(s)){
							targetPR = pr;
							System.out.println("Found Match!");
							side_panel.removeAll();
							side_updates.removeAll();
							side_panel.setLayout(new GridLayout(0,1));
							side_title.setText("Title: "+pr.getTitle());
							side_panel.add(side_title);
							side_rby.setText("Requested by: "+pr.getRequested_by());
							side_panel.add(side_rby);
							side_status.setText("Status: "+pr.getStatus());
							side_panel.add(side_status);
							side_desc.setText("Description: "+pr.getDescription());
							side_panel.add(side_desc);
							side_updates.setLayout(new GridLayout(0,1));
							side_updates.setBackground(Color.WHITE);
							side_panel.add(new JLabel("Updates: "));
							for(String update : pr.getUpdates()){
								side_updates.add(new JLabel("    "+ update));
							}
							side_panel.add(side_updates);
							//side_percent.setText("Progress: ");
							JProgressBar pg = new JProgressBar(0,100);
							pg.setValue(pr.getPercent_completion());
							pg.setString("Progress");
							pg.setStringPainted(true);
							side_panel.add(pg);
							side_panel.add(side_percent);
							side_panel.setVisible(true);
							side_scroll.setBackground(Color.WHITE);
							side_panel.updateUI();
							update_button.setVisible(true);							
							progress_button.setVisible(true);
							break;
						}else{
							side_panel.removeAll();
							side_updates.removeAll();
							side_panel.updateUI();
							progress_button.setVisible(false);
							update_button.setVisible(false);
						}
				}else{
					side_panel.removeAll();
					side_updates.removeAll();
					side_panel.updateUI();
					progress_button.setVisible(false);
					update_button.setVisible(false);
				}
			}
			
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	};
	
	ActionListener button_lis = new ActionListener(){
		public void actionPerformed(ActionEvent e){
			if(e.getSource() == add_button){
				String title = JOptionPane.showInputDialog(null, "Title:", "What should it be called?");
				String rby = JOptionPane.showInputDialog(null, "Requested by:", "Who wants this?");
				String desc = JOptionPane.showInputDialog(null, "Description:", "What is it about?");
				PR pr = new PR(title,rby,desc);
				PR.pr_list.add(pr);
				JPanel pn = new JPanel();
				pn.add(new JLabel("Title: "+ pr.getTitle()));
				pn.add(new JLabel("Status: "+ pr.getStatus()));
				pn.add(new JLabel("Requested by: "+ pr.getRequested_by()));
				pn.add(new JLabel("Last Update: "+ pr.getLUpdate()));
				pn.setBorder(new LineBorder(Color.BLACK,1));
				if(queue_panel.getComponentCount() % 2 == 0)
					pn.setBackground(Color.WHITE);
				
				pn.setToolTipText(String.format("%s%n%s%n%.2f",pr.getDescription(),pr.getLUpdate(),pr.getPercent_completion()));
				queue_panel.add(pn);
				GUI.this.pack();
			}
			if(e.getSource() == update_button){
				if(target != null){
					String s = JOptionPane.showInputDialog(null, "Update", "Add an Update",JOptionPane.INFORMATION_MESSAGE);
					targetPR.addAnUpdate(s);
				}
			}
			if(e.getSource() == progress_button){
				if(target != null){
					String s = JOptionPane.showInputDialog(null, "Percent Compeletion:", "e.g. 100%",JOptionPane.INFORMATION_MESSAGE).trim();
					try{
						int p = Integer.parseInt(s);
						targetPR.setPercent_completion(p);
					}catch(Exception e1){
						JOptionPane.showMessageDialog(null,"Not a Number!, Make sure it's a number, with no spaces or weird things","Error in reading progress!",JOptionPane.ERROR_MESSAGE);
					}
					
				}
			}
			
		}
	};
	
	ActionListener menu_lis = new ActionListener(){
		public void actionPerformed(ActionEvent e){
			if(e.getSource() == refresh){
				//GUI.this.dispose();
				queue_panel.removeAll();
				queue_list.clear();
				getPRs();
				queue_panel.updateUI();
				if(target != null){
					target = null;
					side_panel.removeAll();
					side_updates.removeAll();
					side_panel.updateUI();
				}
				JOptionPane.showMessageDialog(null, "Refreshed!","Notice",JOptionPane.INFORMATION_MESSAGE);
				
				
				//new GUI();
				
			}
			
			if(e.getSource() == about){
				JOptionPane.showMessageDialog(null, "This Program is Designed to help it's Owner to arrange Programming requests and keep track of their progress","About This Program",JOptionPane.INFORMATION_MESSAGE);
			}
		}
	};
	
	public static void getPRs(){
		queue_panel.removeAll();
		queue_list.clear();
		int i = 0;
		for(PR pr : PR.pr_list){
			
			JPanel pn = new JPanel();
			pn.add(new JLabel("Title: "+ pr.getTitle()));
			pn.add(new JLabel("Status: "+ pr.getStatus()));
			pn.add(new JLabel("Requested by: "+ pr.getRequested_by()));
			pn.add(new JLabel("Last Update: "+ pr.getLUpdate()));
			pn.setBorder(new LineBorder(Color.BLACK,1));
			if(i%2 == 0)
				pn.setBackground(Color.WHITE);
			
			queue_list.add(pn);
			i++;
		}
		for(JPanel pn : queue_list){
			queue_panel.add(pn);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
	

}
